import React from 'react';
import { useParams } from 'react-router-dom';
import periods from '../data';

function PeriodPage() {
  const { id } = useParams();
  const period = periods.find(p => p.id === id);

  if (!period) return <h2>Periode ikke funnet</h2>;

  return (
    <div className="container">
      <h1>{period.name}</h1>
      <p>{period.description}</p>
      <a href={period.snlLink} target="_blank" rel="noopener noreferrer" className="btn btn-primary">Les mer på SNL</a>
    </div>
  );
}

export default PeriodPage;