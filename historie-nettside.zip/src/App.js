import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import PeriodPage from './pages/PeriodPage';
import Navbar from './components/Navbar';

function App() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/period/:id" element={<PeriodPage />} />
      </Routes>
    </div>
  );
}

export default App;